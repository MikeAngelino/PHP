<body>
    <footer>
        <h1>This is my footer</h1>
    </footer>
</body>
